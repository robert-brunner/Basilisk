import { useState } from 'react';

export default function BackgroundPanel({ bgColor, setBgColor, onImageChange }) {
  const [mode, setMode] = useState('color');

  const chooseMode = m => {
    setMode(m);
    if (m === 'color') onImageChange(null);
  };

  return (
    <div>
      <h2>Background</h2>
      <div className="tabbtns">
        <button className={mode === 'color' ? 'active' : ''} onClick={() => chooseMode('color')}>Color</button>
        <button className={mode === 'image' ? 'active' : ''} onClick={() => chooseMode('image')}>Image</button>
      </div>

      {mode === 'color' && (
        <div className="row">
          <label>Fill color</label>
          <input type="color" value={bgColor} onChange={e => setBgColor(e.target.value)} />
          <span className="val">{bgColor}</span>
        </div>
      )}

      {mode === 'image' && (
        <div className="row">
          <input
            type="file"
            accept="image/*"
            onChange={e => {
              const file = e.target.files[0];
              if (file) onImageChange(URL.createObjectURL(file));
            }}
          />
        </div>
      )}
    </div>
  );
}
