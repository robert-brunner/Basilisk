import { useState } from 'react';
import { defaultLayers, makeLayer } from './shadowEngine';
import LayerCard from './components/LayerCard';
import BackgroundPanel from './components/BackgroundPanel';
import PastePanel from './components/PastePanel';
import PreviewPanel from './components/PreviewPanel';
import './App.css';

export default function App() {
  const [bgColor, setBgColor] = useState('#d9d9d9');
  const [bgImage, setBgImage] = useState(null);
  const [radius, setRadius] = useState(24);
  const [layers, setLayers] = useState(defaultLayers());

  const updateLayer = (id, updated) => {
    setLayers(prev => prev.map(l => (l.id === id ? updated : l)));
  };

  const removeLayer = id => {
    setLayers(prev => prev.filter(l => l.id !== id));
  };

  const addLayer = () => {
    setLayers(prev => [...prev, makeLayer()]);
  };

  const handlePasteLoad = result => {
    if (result.bgColor) setBgColor(result.bgColor);
    if (result.radius !== null) setRadius(result.radius);
    if (result.layers) setLayers(result.layers);
  };

  return (
    <div className="app">
      <div className="panel">
        <h1>Box shadow / neumorphism generator</h1>

        <PastePanel onLoad={handlePasteLoad} />

        <BackgroundPanel bgColor={bgColor} setBgColor={setBgColor} onImageChange={setBgImage} />

        <h2>Box radius</h2>
        <div className="row">
          <label>Corner radius</label>
          <input type="range" min="0" max="200" value={radius} onChange={e => setRadius(parseFloat(e.target.value))} />
          <span className="val">{radius}px</span>
        </div>

        <h2>Shadow layers</h2>
        {layers.map((layer, i) => (
          <LayerCard
            key={layer.id}
            layer={layer}
            index={i}
            onChange={updated => updateLayer(layer.id, updated)}
            onRemove={() => removeLayer(layer.id)}
          />
        ))}
        <button id="addLayerBtn" onClick={addLayer}>+ Add shadow layer</button>
      </div>

      <PreviewPanel bgColor={bgColor} bgImage={bgImage} radius={radius} layers={layers} />
    </div>
  );
}
